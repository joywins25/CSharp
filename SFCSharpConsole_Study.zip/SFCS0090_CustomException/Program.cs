﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SFCS0090_CustomException
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
